﻿using System;

namespace OOP_Fundamentals_Library
{
    public class PayrollSystem
    {
        // Метод полагается на полиморфный метод ApplyAnnualRaise()
        public void ProcessSalaryIncrease(Employee employee)
        {
            if (employee == null) throw new ArgumentNullException(nameof(employee));

            // Динамическая диспетчеризация вызовет правильный метод
            employee.ApplyAnnualRaise();

            Console.WriteLine($"New salary for {employee.Name}: {employee.Salary:C}");
        }

        // Метод делегирует расчет самому объекту
        public decimal CalculateBonus(Employee employee, int years, bool hasCert)
        {
            if (employee == null) throw new ArgumentNullException(nameof(employee));
            return employee.CalculateBonus(years, hasCert);
        }
    }
}