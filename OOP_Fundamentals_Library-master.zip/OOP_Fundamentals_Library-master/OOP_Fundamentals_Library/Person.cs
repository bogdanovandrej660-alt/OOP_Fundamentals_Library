﻿using System;

namespace OOP_Fundamentals_Library
{
    public abstract class Person
    {
        // Инкапсуляция
        public string Name { get; private set; }

        private int _age;
        public int Age
        {
            get => _age;
            private set
            {
                if (value < 0 || value > 120)
                    throw new ArgumentException("Age must be between 0 and 120.");
                _age = value;
            }
        }

        protected Person(string name, int age)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name cannot be empty.");

            Name = name;
            Age = age;
        }

        // Полиморфизм
        public virtual void PrintInfo()
        {
            Console.WriteLine($"{this.GetType().Name}: {Name}, {Age} years old");
        }
    }
}