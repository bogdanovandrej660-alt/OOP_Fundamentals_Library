﻿using System;

namespace OOP_Fundamentals_Library
{
    public class Employee : Person
    {
        private decimal _salary;
        public decimal Salary
        {
            get => _salary;
            protected set // protected позволяет менять зарплату в наследниках
            {
                if (value < 0)
                    throw new ArgumentException("Salary cannot be negative.");
                _salary = value;
            }
        }

        public string Position { get; private set; }

        public Employee(string name, int age, decimal salary, string position)
            : base(name, age)
        {
            Salary = salary;
            Position = position;
        }

        public override void PrintInfo()
        {
            base.PrintInfo(); // Используем логику родителя
            Console.WriteLine($"  Position: {Position}, Salary: {Salary:C}");
        }

        // Инкапсуляция изменения состояния
        public void IncreaseSalary(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentException("Increase amount must be positive.");
            Salary += amount;
        }

        // Полиморфизм: Виртуальный метод вместо if/else в PayrollSystem (логика +1000)
        public virtual void ApplyAnnualRaise()
        {
            Console.WriteLine($"Processing standard raise for {Name}...");
            IncreaseSalary(1000);
        }

        // Полиморфизм: Виртуальный метод вместо if/else в PayrollSystem (расчет бонуса)
        public virtual decimal CalculateBonus(int yearsOfExperience, bool hasCertification)
        {
            // Базовая логика для обычного сотрудника (10%)
            decimal bonus = Salary * 0.10m;

            if (yearsOfExperience > 5) bonus += 500;
            if (hasCertification) bonus += 300;

            return bonus;
        }
    }
}