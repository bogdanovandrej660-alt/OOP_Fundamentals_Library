﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OOP_Fundamentals_Library
{
    // Наследование: Manager ЯВЛЯЕТСЯ Employee
    public class Manager : Employee
    {
        public string Department { get; private set; }

        // Инкапсуляция коллекции: закрываем прямой доступ к списку
        private readonly List<Employee> _team = new();
        public IReadOnlyList<Employee> Team => _team.AsReadOnly();

        public Manager(string name, int age, decimal salary, string department)
            : base(name, age, salary, "Manager")
        {
            Department = department;
        }

        public void AddSubordinate(Employee emp)
        {
            if (emp == null) throw new ArgumentNullException(nameof(emp));
            if (_team.Contains(emp)) return;

            _team.Add(emp);
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"Manager: {Name}, {Age} years old (Dept: {Department})");
            Console.WriteLine($"  Team Size: {_team.Count}");
            Console.WriteLine($"  Base Salary: {Salary:C}");
        }

        public void AssignTask(Employee emp, string task)
        {
            if (!_team.Contains(emp))
            {
                Console.WriteLine($"Error: {emp.Name} is not in {Name}'s team.");
                return;
            }
            Console.WriteLine($"Manager {Name} assigned '{task}' to {emp.Name}");
        }

        // Полиморфизм: Переопределение логики повышения (+2000 для менеджера)
        public override void ApplyAnnualRaise()
        {
            Console.WriteLine($"Processing MANAGER raise for {Name}...");
            IncreaseSalary(2000);
        }

        // Полиморфизм: Переопределение логики бонуса (20% для менеджера)
        public override decimal CalculateBonus(int yearsOfExperience, bool hasCertification)
        {
            decimal bonus = Salary * 0.20m; // 20% вместо 10%

            if (yearsOfExperience > 5) bonus += 500;
            if (hasCertification) bonus += 300;

            return bonus;
        }
    }
}