﻿using System;

namespace OOP_Fundamentals_Library
{
    public static class ReportService
    {
        // Принимает любого Employee (включая Manager)
        public static void GenerateReport(Employee emp)
        {
            Console.WriteLine("---------------- REPORT ----------------");
            // Вызовет переопределенный PrintInfo() у конкретного объекта
            emp.PrintInfo();
            Console.WriteLine("----------------------------------------");
        }
    }
}