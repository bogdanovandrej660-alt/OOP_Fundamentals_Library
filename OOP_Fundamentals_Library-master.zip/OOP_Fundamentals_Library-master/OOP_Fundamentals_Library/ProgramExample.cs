﻿namespace OOP_Fundamentals_Library
{
    internal class ProgramExample
    {
        static void Main(string[] args)
        {
            try
            {
                // 1. Создание объектов (валидация работает)
                var customer = new Customer("John", 30);

                var employee = new Employee("Alice", 25, 50000, "Developer");

                var manager = new Manager("Bob", 40, 80000, "IT");

                // 2. Работа с инкапсулированной коллекцией
                manager.AddSubordinate(employee);

                // 3. Вывод информации (Полиморфизм)
                Console.WriteLine("--- Initial State ---");
                customer.PrintInfo();
                ReportService.GenerateReport(employee);
                ReportService.GenerateReport(manager);

                // 4. Payroll System (Полиморфизм в действии)
                var payroll = new PayrollSystem();

                Console.WriteLine("\n--- Processing Raises ---");
                // Для Employee вызовется метод с +1000
                payroll.ProcessSalaryIncrease(employee);
                // Для Manager вызовется метод с +2000 (т.к. Manager переопределил его)
                payroll.ProcessSalaryIncrease(manager);

                // 5. Расчет бонусов
                Console.WriteLine("\n--- Calculating Bonuses ---");
                decimal empBonus = payroll.CalculateBonus(employee, 6, true);
                Console.WriteLine($"Bonus for {employee.Name}: {empBonus:C}"); // 10% + доплаты

                decimal mgrBonus = payroll.CalculateBonus(manager, 6, true);
                Console.WriteLine($"Bonus for {manager.Name}: {mgrBonus:C}"); // 20% + доплаты
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}